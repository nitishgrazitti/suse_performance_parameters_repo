package automation.PageSpeedInsights;

public class Constants {

	public static String excelFileLocation = System.getProperty("user.dir") + "/src/main/java/ModernStarLinks.xlsx";
	public static String win_chromePath =System.getProperty("user.dir")+"./drivers/chromedriver.exe"; 
}
